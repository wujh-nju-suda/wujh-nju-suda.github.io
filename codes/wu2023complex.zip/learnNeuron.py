import argparse
import matplotlib.pyplot as plt
import numpy as np
import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
plt.rcParams.update({'font.size': 22})

class Dataset():
    def __init__(self, features, labels) -> None:
        self.data_size = labels.shape[2]
        self.train_size = int(0.7 * self.data_size)
        self.train_feature = features[:, :, 0: self.train_size, :]
        self.train_label = labels[:, :, 0: self.train_size, :]
        self.test_feature = features[:, :, self.train_size: self.data_size, :]
        self.test_label = labels[:, :, self.train_size: self.data_size, :]

class Net(nn.Module):
    def __init__(self, type, args) -> None:
        super(Net, self).__init__()
        self.type = type
        if (self.type == 'real'):
            self.fc = nn.Linear(2 * args.input_dimension, 1, bias = args.using_bias)
        elif (self.type == 'complex'):
            self.fc_real = nn.Linear(args.input_dimension, 1, bias = args.using_bias)
            self.fc_imag = nn.Linear(args.input_dimension, 1, bias = args.using_bias)
            # special treatment for psi
            self.psi = nn.Linear(1, 1)
            self.psi.weight = nn.parameter.Parameter(torch.ones_like(self.psi.weight, requires_grad = False))
            if (args.target_type == 'complex'):
                self.psi.bias = nn.parameter.Parameter(0.75 + 0.05 * torch.rand(1, requires_grad = True))
            else:
                self.psi.bias = nn.parameter.Parameter(1.3 + 0.05 * torch.rand(1, requires_grad = True))
        else:
            print('Error: neuron type {0} is not defined. It should be \'real\' or \'imag\'.'.format(type))
            sys.exit()
    
    def forward(self, x, args):
        if (self.type == 'real'): # relu activation for real neuron
            return F.relu(self.fc(x))
        elif (self.type == 'complex'): # zrelu activation for complex neuron
            real = self.fc_real(x[:, :, :, 0 : args.input_dimension]) + self.fc_imag(x[0, 0, :, args.input_dimension : 2 * args.input_dimension])
            imag = self.fc_imag(x[:, :, :, 0 : args.input_dimension]) - self.fc_real(x[0, 0, :, args.input_dimension : 2 * args.input_dimension])
            return self.realPartZrelu(real, imag)

    def realPartZrelu(self, real, imag):
        return F.threshold(real, 0, 0) * self.step(imag / real + torch.tan(self.psi.bias), 0) * self.step(- imag / real + torch.tan(self.psi.bias), 0)
    
    def step(self, x, threshold):
        return F.threshold(x, threshold, 0) * F.threshold(1 / x, threshold, 0)

class SettingParas():
    def __init__(self, learning_type, target_type, using_bias, activation_real, activation_complex, input_dim, data_size, num_epoch) -> None:
        self.learning_type = learning_type
        self.target_type = target_type
        self.using_bias = using_bias
        self.activation_real = activation_real
        self.activation_complex = activation_complex
        self.input_dim = input_dim
        self.data_size = data_size
        self.num_epoch = num_epoch

    def setLearningType(self, learning_type):
        self.learning_type = learning_type

    def setTargetType(self, target_type):
        self.target_type = target_type

def generateDataset(args):
    features = torch.randn(1, 1, args.data_size, 2 * args.input_dimension)
    target_model = Net(args.target_type, args)
    labels = target_model(features, args)
    dataset = Dataset(features, labels)
    return dataset

def learnNeuron(args):
    # generate dataset
    dataset = generateDataset(args)
    # initialize loss record and loss function
    test_loss_record = [[], []]
    criterion = nn.MSELoss()
    # set learning type
    for i_type, learning_type in enumerate(['real', 'complex']):
        # initialize model
        model = Net(learning_type, args)
        optimizer = optim.SGD(model.parameters(), lr = 0.1)
        for i_epoch in range(args.num_epoch):
            optimizer.zero_grad()
            # train loss
            train_output = model(dataset.train_feature, args)
            train_loss = criterion(train_output, dataset.train_label)
            # test loss
            test_output = model(dataset.test_feature, args)
            test_loss = criterion(test_output, dataset.test_label)
            test_loss_record[i_type].append(test_loss.item())
            # update model
            train_loss.backward(retain_graph = True)
            optimizer.step()
    # plot and save
    plotLoss(test_loss_record, args.target_type)

def plotLoss(test_loss_record, target_type):
    # generate x and y vectors
    x = [i+1 for i in range(len(test_loss_record[0]))]
    y_test_real = test_loss_record[0]
    y_test_complex = test_loss_record[1]
    # plot
    plt.plot(x, y_test_real, color = 'cyan', label = 'Real Neuron')
    plt.plot(x, y_test_complex, color = 'tomato', label = 'Complex Neuron')
    # set axis range
    y_max = np.ceil(max(test_loss_record[0][0], test_loss_record[1][0]) / 0.1) * 0.1
    plt.axis([0, len(test_loss_record[0]), 0, y_max])
    # add axis name
    plt.xlabel('Number of Epochs')
    plt.ylabel('Test Error')
    # add title
    plt.title('Test Error of Learning a {0} Neuron'.format(str.capitalize(target_type)))
    # add legend
    plt.legend()
    # output 
    plt.show()

if __name__=='__main__':
    parser = argparse.ArgumentParser(description='Simulation')
    parser.add_argument('--data_size', default=10000, type=int)
    parser.add_argument('--input_dimension', default=1, type=int)
    parser.add_argument('--target_type', default='real', type=str) # type of target neuron, 'real' or 'imag'
    parser.add_argument('--using_bias', default=0, type=int) # 0 for no bias, others for using bias
    parser.add_argument('--num_epoch', default=100, type=int)
    args = parser.parse_args()

    learnNeuron(args)
